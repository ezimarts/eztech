variable "aws_region" {
  description = "AWS region for Lambda, API Gateway, S3, and DynamoDB."
  type        = string
  default     = "us-east-1"
}

variable "project_name" {
  description = "Project prefix used for resource names."
  type        = string
  default     = "ezimarts"
}

variable "domain_name" {
  description = "Main website domain. Example: ezimarts.com. Leave empty to skip custom domain certificate."
  type        = string
  default     = ""
}

variable "hosted_zone_id" {
  description = "Route 53 hosted zone ID. Leave empty if DNS is managed outside Route 53."
  type        = string
  default     = ""
}

variable "stripe_publishable_key" {
  description = "Stripe publishable key used by frontend."
  type        = string
  default     = "pk_test_REPLACE_ME"
}

variable "stripe_secret_key" {
  description = "Stripe secret key for Lambda. Use terraform.tfvars or environment variable."
  type        = string
  default     = "sk_test_REPLACE_ME"
  sensitive   = true
}

variable "paypal_client_id" {
  description = "PayPal client ID used by frontend."
  type        = string
  default     = "REPLACE_WITH_PAYPAL_CLIENT_ID"
}
